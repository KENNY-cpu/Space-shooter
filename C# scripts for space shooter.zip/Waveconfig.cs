﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Enemy wave Config")]
public class Waveconfig : ScriptableObject
{
    [SerializeField] GameObject EnemyPrefab;
    [SerializeField] GameObject pathPrefab;
    [SerializeField] float timeBetweenSpawns = 0.5f;
    [SerializeField] float spawnRandomFactor = 0.3f;
    [SerializeField] int numberOfEnemies = 5;
    [SerializeField] float moveSpeed = 2f; //move speed of the enemies 

    public GameObject GetEnemyPrefab() { return EnemyPrefab; } //

    public List<Transform> GetWaypoints()
    {
        var waveWaypoints = new List<Transform>();
        foreach (Transform child in pathPrefab.transform) //For each is what the type is 
        {
            waveWaypoints.Add(child);
        }
        return waveWaypoints; //returning the wave waypoints with in the path prefab

    }

    public float GetTimeBetweenSpawns() { return timeBetweenSpawns; }

    public float GetspawnRandomFactor() { return spawnRandomFactor; }

    public int   GetNumberOfEnemies() { return numberOfEnemies;}

    public float GetMoveSpeed() { return moveSpeed; }


}