﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour // you're inheriting from this shared meta "bass class" 
{
    [Header("Player ")] //this is to help organise 
    // configuration parameters
    [SerializeField] float moveSpeed = 5f; // This is for the movespeed of the ship "SerializeField" means creating an element that can be saved to the disk 
    [SerializeField] float padding = 1f; // this is to set boundaries so the ship won't go off screen 
    [SerializeField] int health = 200;
    [SerializeField] AudioClip deadSound;
    [SerializeField] [Range(0, 1)] float deadSoundvolume = 0.75f;
    [SerializeField] AudioClip shootSound;
    [SerializeField] [Range(0, 1)] float shootSoundVolume = 0.25f;


    [Header("Projectile")]
    [SerializeField] GameObject PlayerLazerPrefab;
    [SerializeField] float projectileSpeed = 10f;
    [SerializeField] float projectileFiringPeriod = 0.1f;

    Coroutine firingCoroutine;

    float xMin;
    float xMax;
    float yMin;
    float yMax;
    // Start is called before the first frame update
    void Start()
    {
        
        SetUpMoveBoundaries();
        
    }

   

    // Update is called once per frame
    void Update()
    {

        Move();
        Fire();
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Damagedealer damageDealer = other.gameObject.GetComponent<Damagedealer>(); //type has uppercase variable has lowercase  
        if (!damageDealer) { return; } // if there is no damage dealer than return 
        ProcessHit(damageDealer);
    }

    private void ProcessHit(Damagedealer damageDealer)
    {
        health -= damageDealer.GetDamage();
        damageDealer.Hit();
        if (health <= 0)
        {
            Die(); //method
        }
    }

    private void Die()
    {
       
       
        Debug.Log("In die method");
        FindObjectOfType<Level>().LoadGameOver();
        Destroy(gameObject);// when the player health is at 0 the player dies
        //AudioSource.PlayClipAtPoint(deadSound, Camera.main.transform.position, deadSoundvolume);
    }

private void Fire()
    {
        if (Input.GetButtonDown("Fire1")) // Fire1 is the spacebar which was applied to in the menu
                                            // When the button is pushed the ship will fire 
        {
           firingCoroutine =  StartCoroutine(FireContinuously()); // This bit of code is for the user if they want to keep holding the spacebar eeither from
                                                                  // constantly pushing it 
        }
        if (Input.GetButtonUp("Fire1")) // firing stops when the button is up
        {
            StopCoroutine(firingCoroutine); // this stops the bullets from continuously being fired 
        } 
    }

    IEnumerator FireContinuously()
    {
        while (true) //Once you hold down the spacebar the firing should be continuous due to the value's being true 
        {


            GameObject Lazer = Instantiate(
                  PlayerLazerPrefab,
                  transform.position,
                  Quaternion.identity) as GameObject;

            Lazer.GetComponent<Rigidbody2D>().velocity = new Vector2(0, projectileSpeed);
            AudioSource.PlayClipAtPoint(shootSound, Camera.main.transform.position, shootSoundVolume);
            yield return new WaitForSeconds(projectileFiringPeriod);

        }
    }

    private void Move()
    {

        var deltaX = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;   // this is how to ship will move through the Horizonal option
        //Debug.Log(deltaX);
        var deltaY = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;   // this is how to ship will move through the Horizonal option
        //Debug.Log(deltaX);

        var newXpos = Mathf.Clamp(transform.position.x + deltaX, xMin, xMax);
        var newYpos = Mathf.Clamp(transform.position.y + deltaY, yMin, yMax);
        transform.position = new Vector2(newXpos, newYpos); //X is for Horizontal and Y is for verticle 




    }

    private void SetUpMoveBoundaries()
    {
        Camera gameCamera = Camera.main;
        xMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).x + padding; //Vector is used for x, y, z dimensions 
        xMax = gameCamera.ViewportToWorldPoint(new Vector3(1, 0, 0)).x - padding;
        yMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).y + padding;
        yMax = gameCamera.ViewportToWorldPoint(new Vector3(0, 1, 0)).y - padding;
    }
   

    
}