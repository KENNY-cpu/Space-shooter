﻿internal class NameOfCoroutine
{
}