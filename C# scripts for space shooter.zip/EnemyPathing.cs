﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPathing : MonoBehaviour

{
     Waveconfig waveConfig;
    List<Transform> waypoints;
    int waypointIndex = 0;
    //which way point am I working towards
    // Start is called before the first frame update
    void Start()
    {
        waypoints = waveConfig.GetWaypoints();
        transform.position = waypoints[waypointIndex].transform.position;
    }

    void Update()
    {
        Move();
        //this will continue unless we have gone to a higher number
    }

    public void SetWaveConfig(Waveconfig waveConfig)
    {
        this.waveConfig = waveConfig; // This is the instance variable from the waveconfig at top the other config is the one in the brackets
    }

     

    private void Move()
    {
        if (waypointIndex <= waypoints.Count - 1)
        {
            var targetPosition = waypoints[waypointIndex].transform.position;
            var movementThisFrame = waveConfig.GetMoveSpeed() * Time.deltaTime;// how fast we want to move
            transform.position = Vector2.MoveTowards
                (transform.position, targetPosition, movementThisFrame);

            if (transform.position == targetPosition)
            {
                waypointIndex++; //increment + 1

            }
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
