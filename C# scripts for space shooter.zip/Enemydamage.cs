﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemydamage : MonoBehaviour
{
    [SerializeField] float health = 100;
    [SerializeField] float shotCounter;
    [SerializeField] float minTimeBetweenShots = 0.2f;
    [SerializeField] float maxTimeBetweenShots = 3f;
    [SerializeField] float projectileSpeed = 10f;
    [SerializeField] float projectileFiringPeriod = 0.1f;
    [SerializeField] GameObject Projectile;
    [SerializeField] GameObject deathVFX;
    [SerializeField] float durationOfExplosion = 1f;
    [SerializeField] AudioClip deathSound;
    [SerializeField] [Range(0,1)]float deathSoundvolume = 0.75f; //3 quearters of maximun volume

    [SerializeField] AudioClip shootSound;
    [SerializeField] [Range(0, 1)] float shootSoundvolume = 0.25f;

    // Start is called before the first frame update
    void Start()
    {
        shotCounter = Random.Range(minTimeBetweenShots, maxTimeBetweenShots);
    }

    // Update is called once per frame
    void Update()
    {
        CountDownandShoot();

    }

    private void CountDownandShoot()
    {
        shotCounter -= Time.deltaTime;
        if (shotCounter <= 0f)
        {
            Fire();
            shotCounter = Random.Range(minTimeBetweenShots, maxTimeBetweenShots);

        }
    }
        private void Fire()
        {
            GameObject RedLazer = Instantiate(
               Projectile,
               transform.position,
               Quaternion.identity

                ) as GameObject;
        AudioSource.PlayClipAtPoint(shootSound, Camera.main.transform.position, shootSoundvolume);
        RedLazer.GetComponent<Rigidbody2D>().velocity = new Vector2(0, -projectileSpeed);
           





    }
        private void OnTriggerEnter2D(Collider2D other)
    {
        Damagedealer damageDealer = other.gameObject.GetComponent<Damagedealer>(); //type has uppercase variable has lowercase  
        if (!damageDealer) { return; } // this protets us from null errors
        ProcessHit(damageDealer);
    }

    private void ProcessHit(Damagedealer damageDealer) 
    {
        health -= damageDealer.GetDamage();
        damageDealer.Hit(); // this should destory the enemy lazer
        if (health <= 0)
        {
            Die();// when the enemy health is at 0 the enemy dies 
        }
    }

    private void Die()
    {
        Destroy(gameObject);
        GameObject explosion = Instantiate(deathVFX, transform.position, transform.rotation);
        Destroy(explosion, 1f);
        AudioSource.PlayClipAtPoint(deathSound, Camera.main.transform.position, deathSoundvolume);
    }
}
