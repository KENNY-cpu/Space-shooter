﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] List<Waveconfig> waveConfigs;
    [SerializeField]int startingWave = 0; //starting at 0 for the wave configs
    [SerializeField] bool looping = false;
    // use this for intitalization
    IEnumerator Start ()
    {

        do
        {
            yield return StartCoroutine(SpawnAllWaves());

        }
        while (looping); // this is to loop all the waves
    }

    private IEnumerator SpawnAllWaves()
    {
        for (int waveIndex = startingWave; waveIndex < waveConfigs.Count; waveIndex++) 
        {
            var currentWave = waveConfigs[ waveIndex ];
            yield return StartCoroutine(SpawnAllEnemiesInWave(currentWave));
        }
    }

    private IEnumerator SpawnAllEnemiesInWave(Waveconfig waveConfig) //IEnumerator is a Corutine
    {
        for (int enemyCount = 0; enemyCount < waveConfig.GetNumberOfEnemies(); enemyCount++)
        {

            var newEnemy = Instantiate( //storing the new enemy
                waveConfig.GetEnemyPrefab(),
                waveConfig.GetWaypoints()[0].transform.position,
                Quaternion.identity);
            newEnemy.GetComponent<EnemyPathing>().SetWaveConfig(waveConfig); // this is grabbing the enemypathing script 
            yield return new WaitForSeconds(waveConfig.GetTimeBetweenSpawns()); //Make sure to push yield to cmake the Courtine work
        }
    }



}